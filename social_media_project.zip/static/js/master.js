$(document).ready(function() {
  $('#atFinalDelete').hide();
});
